from django.shortcuts import render, redirect
from django.contrib.auth import logout, login
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

from .utils import is_ajax, classify_face
import base64
from logs.models import Log
from django.core.files.base import ContentFile
from django.contrib.auth.models import User
from profiles.models import Profile

def login_view(request):
    return render(request, 'login.html', {})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home_view(request):
    return render(request, 'main.html', {})

# Removed duplicate imports

def find_user_view(request):
    # Verificar si la solicitud es AJAX
    if request.is_ajax():
        photo = request.POST.get('photo')
        
        # Verificar que 'photo' esté en los datos POST
        if not photo:
            return JsonResponse({'success': False, 'error': 'No photo provided'}, status=400)

        try:
            # Decodificar la imagen base64
            _, str_img = photo.split(';base64,')
            decoded_file = base64.b64decode(str_img)
        except (ValueError, TypeError, base64.binascii.Error) as e:
            # Error en la decodificación de la imagen
            return JsonResponse({'success': False, 'error': f'Image decoding error: {str(e)}'}, status=400)

        # Guardar la imagen en el modelo Log
        x = Log()
        x.photo.save('foto_cargada.png', ContentFile(decoded_file))
        x.save()

        try:
            # Clasificar el rostro usando la función classify_face
            res = classify_face(x.photo.path)
        except Exception as e:
            # Error al clasificar el rostro
            return JsonResponse({'success': False, 'error': f'Face classification error: {str(e)}'}, status=500)

        if res:
            try:
                # Verificar si el usuario existe
                user = User.objects.get(username=res)
                profile = Profile.objects.get(user=user)
                
                # Asignar el perfil al registro de Log y guardar
                x.profile = profile
                x.save()
                
                # Iniciar sesión del usuario
                login(request, user)
                return JsonResponse({'success': True})
            except User.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'User does not exist'}, status=404)
            except Profile.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'Profile does not exist'}, status=404)

        # Si el usuario no fue reconocido
        return JsonResponse({'success': False, 'error': 'Face not recognized'}, status=400)

    # Si la solicitud no es AJAX, devolver error
    return JsonResponse({'success': False, 'error': 'Invalid request type'}, status=400)
